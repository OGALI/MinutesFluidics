---
path: '/team/josh'
title: 'Josh Ou'
date: 2018-11-19T10:47:58+10:00
draft: false
image: '/team/josh.jpg'
jobtitle: 'Manufacturing'
email: 'jiachi.ou@mail.mcgill.ca'
linkedinurl: 'https://www.linkedin.com/in/jiachiou/'
weight: 4
---

Jiachi completed U4 Bioengineering in Stream 2: Biomolecular and Cellular Engineering. Jiachi has a good background in molecular biology and has four years of research experience from different laboratories. He is interested in biomolecular probe design and manufacturing. For our initiative, he focuses on nucleic acid probe design and on its implementation in disposable diagnostic equipment.
