---
path: '/team/william'
title: 'William Pang'
date: 2018-11-19T10:47:58+10:00
draft: false
image: '/team/william.jpg'
jobtitle: 'Public Health'
email: 'william.pang@mail.mcgill.ca'
linkedinurl: 'https://www.linkedin.com/in/william-pang-lh/'
weight: 5
---

William is a U4 Bioengineering student in Stream 2: Biomolecular and Cellular Engineering. Will is well versed in bioengineering/biotechnology and is currently as an undergraduate research student in the Stem Cell Bioprocessing Laboratory. At MinutesFluidics, Will is particularly interested in investigating how our product can play a vital role in the context of public health.
